"""Generate app icons for FORGE PWA."""
from PIL import Image, ImageDraw, ImageFont
import os

OUTPUT = '/home/claude/forge-pwa/public'

# Colors
BG = (9, 9, 11)            # zinc-950
BG_INNER = (24, 24, 27)    # zinc-900
ACCENT = (74, 222, 128)    # emerald-400
DARK_ACCENT = (16, 185, 129)


def find_font(size, bold=True):
    """Try to find a clean bold font on the system."""
    candidates = [
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
        '/usr/share/fonts/TTF/DejaVuSans-Bold.ttf',
    ]
    for c in candidates:
        if os.path.exists(c):
            return ImageFont.truetype(c, size)
    return ImageFont.load_default()


def make_icon(size, maskable=False, transparent_bg=False, padding_factor=0.15):
    """Create a square icon at the given size."""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    if maskable:
        # Maskable icons need a safe zone - fill entire area with bg
        draw.rectangle([0, 0, size, size], fill=BG)
        inset = int(size * 0.15)
    else:
        # Rounded square background
        radius = int(size * 0.22)
        draw.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=BG)
        inset = int(size * padding_factor)

    # Inner subtle background card
    inner_radius = max(1, int((size - 2 * inset) * 0.18))
    if not maskable:
        # subtle inner gradient effect with a slightly lighter rectangle
        pass

    # Draw a stylized "F." mark in accent green
    # Use a large bold font
    font_size = int(size * 0.62)
    font = find_font(font_size, bold=True)

    text = 'F'
    # Calculate text size
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]

    # Center, but shift slightly left to leave room for the dot accent
    text_x = (size - tw) // 2 - bbox[0] - int(size * 0.04)
    text_y = (size - th) // 2 - bbox[1] - int(size * 0.04)
    draw.text((text_x, text_y), text, fill=ACCENT, font=font)

    # Accent dot (the period)
    dot_size = int(size * 0.13)
    dot_x = text_x + tw + int(size * 0.02)
    dot_y = size - inset - dot_size - int(size * 0.05)
    if maskable:
        dot_y = int(size * 0.72)
        dot_x = int(size * 0.62)
    draw.ellipse([dot_x, dot_y, dot_x + dot_size, dot_y + dot_size], fill=ACCENT)

    return img


# Generate sizes
for size, name in [(192, 'icon-192.png'), (512, 'icon-512.png'), (180, 'icon-180.png')]:
    icon = make_icon(size, maskable=False)
    icon.save(os.path.join(OUTPUT, name), 'PNG')
    print(f'Wrote {name} ({size}x{size})')

# Maskable version (full-bleed, safe zone)
maskable = make_icon(512, maskable=True)
maskable.save(os.path.join(OUTPUT, 'icon-512-maskable.png'), 'PNG')
print('Wrote icon-512-maskable.png')

# Favicon (32x32)
fav = make_icon(64, maskable=False)
fav = fav.resize((32, 32), Image.LANCZOS)
fav.save(os.path.join(OUTPUT, 'favicon.png'), 'PNG')
print('Wrote favicon.png')
