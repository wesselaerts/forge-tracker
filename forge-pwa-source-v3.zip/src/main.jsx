import React from 'react';
import { createRoot } from 'react-dom/client';
import SportTracker from './SportTracker.jsx';

const root = createRoot(document.getElementById('root'));
root.render(<SportTracker />);

// Register service worker for PWA / offline support
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(err => {
      console.log('SW registration failed:', err);
    });
  });
}
