import { useState, useEffect, useMemo } from 'react';
import {
  LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid,
  BarChart, Bar, AreaChart, Area
} from 'recharts';
import {
  Dumbbell, Heart, Calendar, BarChart3, Settings as SettingsIcon,
  Check, X, Plus, Trash2, Edit2, Download, TrendingUp, Flame, Award,
  ChevronRight, ChevronLeft, ChevronDown, Save, RotateCcw, Activity,
  Scale, Target, Clock, MapPin, FileText, Zap, Trophy, ArrowLeft, Percent
} from 'lucide-react';

// ============ DEFAULTS ============

const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
const DAY_LABELS_NL = {
  monday: 'Maandag', tuesday: 'Dinsdag', wednesday: 'Woensdag',
  thursday: 'Donderdag', friday: 'Vrijdag', saturday: 'Zaterdag', sunday: 'Zondag'
};
const DAY_SHORT_NL = {
  monday: 'Ma', tuesday: 'Di', wednesday: 'Wo',
  thursday: 'Do', friday: 'Vr', saturday: 'Za', sunday: 'Zo'
};

const DEFAULT_SCHEDULE = {
  monday: { type: 'strength', muscleGroup: 'chest', name: 'Borst' },
  tuesday: { type: 'strength', muscleGroup: 'shoulders_back', name: 'Schouder + Rug' },
  wednesday: { type: 'cardio', cardioType: 'run', name: 'Bosrun' },
  thursday: { type: 'rest', name: 'Rust (school)' },
  friday: { type: 'rest', name: 'Rust' },
  saturday: { type: 'cardio', cardioType: 'rowing', name: 'Roeimachine' },
  sunday: { type: 'rest', name: 'Rust' }
};

const DEFAULT_MUSCLE_GROUPS = {
  chest: { label: 'Borst', exercises: ['Bench press', 'Incline DB press', 'Cable fly', 'Push-ups'] },
  shoulders_back: { label: 'Schouder + Rug', exercises: ['Lat pulldown', 'Seated row', 'Lateral raises', 'Face pulls', 'Rear delt fly'] },
  legs: { label: 'Benen', exercises: ['Squat', 'Lunges', 'Leg press', 'Calf raises'] },
  arms: { label: 'Armen', exercises: ['Bicep curl', 'Tricep pushdown', 'Hammer curl'] },
  core: { label: 'Core', exercises: ['Plank', 'Hanging leg raises', 'Cable crunch'] }
};

const CARDIO_TYPES = {
  run: { label: 'Hardlopen', icon: '🏃' },
  rowing: { label: 'Roeien', icon: '🚣' },
  bike: { label: 'Fietsen', icon: '🚴' },
  walk: { label: 'Wandelen', icon: '🚶' },
  other: { label: 'Anders', icon: '💨' }
};

// ============ DATE HELPERS ============

function toISODate(date) {
  const d = new Date(date);
  return d.getFullYear() + '-' +
    String(d.getMonth() + 1).padStart(2, '0') + '-' +
    String(d.getDate()).padStart(2, '0');
}

function getMondayOfWeek(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.setDate(diff));
}

function addDays(date, days) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

function getISOWeek(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNum = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNum).padStart(2, '0')}`;
}

function getDayKey(date) {
  return DAYS[(new Date(date).getDay() + 6) % 7];
}

function formatDate(date) {
  const d = new Date(date);
  return d.toLocaleDateString('nl-NL', { day: 'numeric', month: 'short' });
}

// ============ STORAGE (localStorage) ============

const STORAGE_PREFIX = 'forge:';

function loadKey(key, fallback) {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + key);
    if (raw === null) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.error('Load failed:', key, e);
    return fallback;
  }
}

function saveKey(key, value) {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.error('Save failed:', key, e);
    return false;
  }
}

// ============ CALORIE ESTIMATION ============
// MET values from Compendium of Physical Activities (Ainsworth et al.)
// kcal = MET × bodyWeight(kg) × duration(hours)

const MET_VALUES = {
  strength: 5.5,       // Vigorous resistance training
  cardio_run: 9.8,     // Running, ~10 km/u
  cardio_rowing: 7.0,  // Rowing machine, moderate-vigorous
  cardio_bike: 7.5,    // Cycling, moderate
  cardio_walk: 4.0,    // Brisk walking
  cardio_other: 5.5
};

const DEFAULT_BODY_WEIGHT = 75; // fallback if no measurement exists

function getCurrentBodyWeight(bodyWeights) {
  if (!bodyWeights || bodyWeights.length === 0) return DEFAULT_BODY_WEIGHT;
  const withWeight = bodyWeights.filter(w => w.weight != null);
  if (withWeight.length === 0) return DEFAULT_BODY_WEIGHT;
  // bodyWeights is sorted ascending by date in App component
  return withWeight[withWeight.length - 1].weight;
}

function estimateSessionDuration(session) {
  // Use explicit duration if provided
  if (session.duration && !isNaN(parseFloat(session.duration))) {
    return parseFloat(session.duration);
  }
  if (session.type === 'cardio') return 30; // sane default
  if (session.type === 'strength') {
    const totalSets = session.exercises?.reduce(
      (sum, ex) => sum + (ex.sets?.length || 0), 0
    ) || 0;
    // ~2.5 min per set including rest, minimum 15 min
    return Math.max(15, Math.round(totalSets * 2.5));
  }
  return 60;
}

function getMETForSession(session) {
  if (session.type === 'strength') return MET_VALUES.strength;
  if (session.type === 'cardio') {
    const key = 'cardio_' + (session.cardioType || 'other');
    return MET_VALUES[key] || MET_VALUES.cardio_other;
  }
  return 0;
}

function calculateCalories(session, bodyWeight) {
  const durationHours = estimateSessionDuration(session) / 60;
  const met = getMETForSession(session);
  return Math.round(met * bodyWeight * durationHours);
}

function findPreviousSimilarSession(currentSession, allSessions) {
  const candidates = allSessions
    .filter(s => {
      if (s.id === currentSession.id) return false; // skip self when editing
      if (s.type !== currentSession.type) return false;
      if (currentSession.type === 'strength') {
        return s.muscleGroup === currentSession.muscleGroup && s.exercises?.length > 0;
      }
      if (currentSession.type === 'cardio') {
        return s.cardioType === currentSession.cardioType;
      }
      return false;
    })
    .filter(s => s.date <= currentSession.date) // only past sessions
    .sort((a, b) => b.date.localeCompare(a.date));
  return candidates[0] || null;
}

function daysBetween(dateA, dateB) {
  const a = new Date(dateA);
  const b = new Date(dateB);
  return Math.round((b - a) / (1000 * 60 * 60 * 24));
}

// ============ MAIN APP ============

export default function SportTracker() {
  const [activeTab, setActiveTab] = useState('week');
  const [loading, setLoading] = useState(true);
  const [schedule, setSchedule] = useState(DEFAULT_SCHEDULE);
  const [muscleGroups, setMuscleGroups] = useState(DEFAULT_MUSCLE_GROUPS);
  const [sessions, setSessions] = useState([]);
  const [bodyWeights, setBodyWeights] = useState([]);
  const [currentWeekStart, setCurrentWeekStart] = useState(() => getMondayOfWeek(new Date()));
  const [toast, setToast] = useState(null);
  const [editingSession, setEditingSession] = useState(null);

  // Load all data on mount (synchronous - localStorage)
  useEffect(() => {
    setSchedule(loadKey('schedule', DEFAULT_SCHEDULE));
    setMuscleGroups(loadKey('muscleGroups', DEFAULT_MUSCLE_GROUPS));
    setSessions(loadKey('sessions', []));
    setBodyWeights(loadKey('bodyWeights', []));
    setLoading(false);
  }, []);

  // Inject fonts
  useEffect(() => {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap';
    document.head.appendChild(link);
    return () => { document.head.removeChild(link); };
  }, []);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2000);
  };

  // Save handlers
  const updateSchedule = async (newSchedule) => {
    setSchedule(newSchedule);
    await saveKey('schedule', newSchedule);
    showToast('Schema opgeslagen');
  };
  const updateMuscleGroups = async (newGroups) => {
    setMuscleGroups(newGroups);
    await saveKey('muscleGroups', newGroups);
  };
  const addSession = async (session) => {
    const newSessions = [...sessions, { ...session, id: Date.now().toString() }];
    setSessions(newSessions);
    await saveKey('sessions', newSessions);
    showToast('Sessie opgeslagen 💪');
  };
  const updateSession = async (session) => {
    const newSessions = sessions.map(s => s.id === session.id ? session : s);
    setSessions(newSessions);
    await saveKey('sessions', newSessions);
    showToast('Sessie bijgewerkt ✓');
  };
  const deleteSession = async (id) => {
    const newSessions = sessions.filter(s => s.id !== id);
    setSessions(newSessions);
    await saveKey('sessions', newSessions);
    showToast('Sessie verwijderd');
  };
  const addBodyWeight = async (entry) => {
    const existing = bodyWeights.find(w => w.date === entry.date);
    const merged = existing ? { ...existing, ...entry } : entry;
    const newWeights = [...bodyWeights.filter(w => w.date !== entry.date), merged]
      .sort((a, b) => a.date.localeCompare(b.date));
    setBodyWeights(newWeights);
    await saveKey('bodyWeights', newWeights);
    showToast('Meting opgeslagen');
  };
  const deleteBodyWeight = async (date) => {
    const newWeights = bodyWeights.filter(w => w.date !== date);
    setBodyWeights(newWeights);
    await saveKey('bodyWeights', newWeights);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center">
        <div className="text-emerald-400 font-mono">laden...</div>
      </div>
    );
  }

  const tabs = [
    { id: 'week', label: 'Week', icon: Calendar },
    { id: 'train', label: 'Train', icon: Dumbbell },
    { id: 'stats', label: 'Stats', icon: BarChart3 },
    { id: 'manage', label: 'Beheer', icon: SettingsIcon }
  ];

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100" style={{ fontFamily: "'Manrope', system-ui, sans-serif" }}>
      <style>{`
        body { font-family: 'Manrope', system-ui, sans-serif; }
        .font-display { font-family: 'Bricolage Grotesque', system-ui, sans-serif; letter-spacing: -0.02em; }
        .font-mono { font-family: 'JetBrains Mono', ui-monospace, monospace; }
        input[type=number]::-webkit-outer-spin-button,
        input[type=number]::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
        input[type=number] { -moz-appearance: textfield; }
        .glow-green { box-shadow: 0 0 20px rgba(74, 222, 128, 0.15); }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
        @keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .anim-slide-up { animation: slideUp 0.3s ease-out; }
      `}</style>

      {/* Top header */}
      <header className="sticky top-0 z-30 backdrop-blur-xl bg-zinc-950/80 border-b border-zinc-800/60">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold leading-none">
              <span className="text-zinc-100">FORGE</span>
              <span className="text-emerald-400">.</span>
            </h1>
            <p className="text-xs text-zinc-500 mt-1 font-mono uppercase tracking-wider">
              {tabs.find(t => t.id === activeTab)?.label}
            </p>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800">
            <Flame className="w-4 h-4 text-emerald-400" />
            <span className="font-mono text-sm font-medium">{calculateStreak(sessions, schedule)}</span>
            <span className="text-xs text-zinc-500">wk</span>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-2xl mx-auto px-4 py-6 pb-32">
        {activeTab === 'week' && (
          <WeekView
            schedule={schedule}
            sessions={sessions}
            muscleGroups={muscleGroups}
            bodyWeights={bodyWeights}
            currentWeekStart={currentWeekStart}
            setCurrentWeekStart={setCurrentWeekStart}
            onStartTrain={() => { setEditingSession(null); setActiveTab('train'); }}
            onEditSession={(session) => { setEditingSession(session); setActiveTab('train'); }}
            onDeleteSession={deleteSession}
          />
        )}
        {activeTab === 'train' && (
          <TrainView
            schedule={schedule}
            muscleGroups={muscleGroups}
            sessions={sessions}
            editingSession={editingSession}
            onSave={addSession}
            onUpdate={updateSession}
            onClearEditing={() => setEditingSession(null)}
          />
        )}
        {activeTab === 'stats' && (
          <StatsView
            sessions={sessions}
            schedule={schedule}
            muscleGroups={muscleGroups}
            bodyWeights={bodyWeights}
            onAddWeight={addBodyWeight}
            onDeleteWeight={deleteBodyWeight}
          />
        )}
        {activeTab === 'manage' && (
          <ManageView
            schedule={schedule}
            muscleGroups={muscleGroups}
            onUpdateSchedule={updateSchedule}
            onUpdateMuscleGroups={updateMuscleGroups}
          />
        )}
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-zinc-950/95 backdrop-blur-xl border-t border-zinc-800/60">
        <div className="max-w-2xl mx-auto px-2 py-2 grid grid-cols-4 gap-1">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex flex-col items-center gap-1 py-3 px-2 rounded-xl transition-all ${
                  active ? 'text-emerald-400' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {active && <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-emerald-400 rounded-full" />}
                <Icon className="w-5 h-5" strokeWidth={active ? 2.5 : 2} />
                <span className={`text-[10px] uppercase tracking-wider font-medium ${active ? 'font-bold' : ''}`}>
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 anim-slide-up">
          <div className="bg-emerald-500 text-zinc-950 px-5 py-2.5 rounded-full font-medium text-sm shadow-lg shadow-emerald-500/30">
            {toast}
          </div>
        </div>
      )}
    </div>
  );
}

// ============ WEEK VIEW ============

function WeekView({ schedule, sessions, muscleGroups, bodyWeights, currentWeekStart, setCurrentWeekStart, onStartTrain, onEditSession, onDeleteSession }) {
  const today = toISODate(new Date());
  const bodyWeight = getCurrentBodyWeight(bodyWeights);
  const weekDays = DAYS.map((day, i) => {
    const date = addDays(currentWeekStart, i);
    return { day, date: toISODate(date), dateObj: date };
  });

  const getDayStatus = (dayInfo) => {
    const planned = schedule[dayInfo.day];
    if (planned.type === 'rest') return { status: 'rest', planned };

    // Check if there's a session matching this planned day
    const directSession = sessions.find(s => s.date === dayInfo.date && s.plannedDay === dayInfo.day);
    if (directSession) return { status: 'done', planned, session: directSession };

    // Check if it was made up on another day this week
    const weekDates = weekDays.map(d => d.date);
    const makeupSession = sessions.find(s =>
      weekDates.includes(s.date) && s.plannedDay === dayInfo.day && s.date !== dayInfo.date
    );
    if (makeupSession) return { status: 'made_up', planned, session: makeupSession };

    if (dayInfo.date < today) return { status: 'missed', planned };
    if (dayInfo.date === today) return { status: 'today', planned };
    return { status: 'upcoming', planned };
  };

  const goPrevWeek = () => setCurrentWeekStart(addDays(currentWeekStart, -7));
  const goNextWeek = () => setCurrentWeekStart(addDays(currentWeekStart, 7));
  const goToday = () => setCurrentWeekStart(getMondayOfWeek(new Date()));

  const weekRange = `${formatDate(currentWeekStart)} – ${formatDate(addDays(currentWeekStart, 6))}`;
  const isThisWeek = toISODate(currentWeekStart) === toISODate(getMondayOfWeek(new Date()));

  // Week stats
  const weekStatuses = weekDays.map(d => getDayStatus(d));
  const totalPlanned = weekStatuses.filter(s => s.status !== 'rest').length;
  const completed = weekStatuses.filter(s => s.status === 'done' || s.status === 'made_up').length;

  // Calorieën deze week
  const weekDates = weekDays.map(d => d.date);
  const thisWeekSessions = sessions.filter(s => weekDates.includes(s.date));
  const weekCalories = thisWeekSessions.reduce((sum, s) => sum + calculateCalories(s, bodyWeight), 0);

  return (
    <div className="space-y-5">
      {/* Week navigation */}
      <div className="flex items-center justify-between">
        <button onClick={goPrevWeek} className="p-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 transition">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="text-center">
          <p className="font-display text-lg font-bold">{weekRange}</p>
          {!isThisWeek && (
            <button onClick={goToday} className="text-xs text-emerald-400 underline-offset-2 hover:underline">
              naar deze week
            </button>
          )}
          {isThisWeek && <p className="text-xs text-zinc-500 font-mono uppercase tracking-wider">deze week</p>}
        </div>
        <button onClick={goNextWeek} className="p-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 transition">
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Progress + Calories */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4">
          <div className="flex items-center gap-1.5 mb-2">
            <Target className="w-3.5 h-3.5 text-zinc-500" />
            <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-mono">Voortgang</span>
          </div>
          <p className="font-display text-3xl font-bold leading-none">
            {completed}<span className="text-zinc-600">/{totalPlanned}</span>
          </p>
          <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden mt-3">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400 rounded-full transition-all duration-500"
              style={{ width: `${totalPlanned > 0 ? (completed / totalPlanned) * 100 : 0}%` }}
            />
          </div>
        </div>
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4">
          <div className="flex items-center gap-1.5 mb-2">
            <Flame className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-mono">Kcal week</span>
          </div>
          <p className="font-display text-3xl font-bold leading-none">
            {weekCalories.toLocaleString('nl-NL')}
          </p>
          <p className="text-[10px] text-zinc-600 font-mono mt-3">
            schatting · {bodyWeight}kg
          </p>
        </div>
      </div>

      {/* Day cards */}
      <div className="space-y-2.5">
        {weekDays.map((dayInfo) => {
          const { status, planned, session } = getDayStatus(dayInfo);
          const isToday = dayInfo.date === today;
          return (
            <DayCard
              key={dayInfo.day}
              dayInfo={dayInfo}
              planned={planned}
              status={status}
              session={session}
              isToday={isToday}
              muscleGroups={muscleGroups}
              bodyWeight={bodyWeight}
              onStartTrain={onStartTrain}
              onEditSession={onEditSession}
              onDeleteSession={onDeleteSession}
            />
          );
        })}
      </div>
    </div>
  );
}

function DayCard({ dayInfo, planned, status, session, isToday, muscleGroups, bodyWeight, onStartTrain, onEditSession, onDeleteSession }) {
  const [expanded, setExpanded] = useState(false);

  const statusConfig = {
    rest: { textClass: 'text-zinc-600', label: 'Rust', icon: null },
    done: { textClass: 'text-emerald-400', label: 'Voltooid', icon: Check },
    made_up: { textClass: 'text-emerald-400', label: 'Ingehaald', icon: RotateCcw },
    missed: { textClass: 'text-red-400', label: 'Gemist', icon: X },
    today: { textClass: 'text-emerald-400', label: 'Vandaag', icon: Target },
    upcoming: { textClass: 'text-zinc-500', label: 'Gepland', icon: Clock }
  };
  const cfg = statusConfig[status];
  const Icon = cfg.icon;

  const getTypeLabel = () => {
    if (planned.type === 'rest') return 'Rustdag';
    if (planned.type === 'cardio') {
      const t = CARDIO_TYPES[planned.cardioType] || CARDIO_TYPES.other;
      return `${t.icon} ${planned.name || t.label}`;
    }
    return `🏋 ${planned.name || muscleGroups[planned.muscleGroup]?.label || 'Krachttraining'}`;
  };

  return (
    <div
      className={`relative rounded-2xl border transition-all ${
        isToday ? 'border-emerald-500/40 glow-green' : 'border-zinc-800'
      } ${status === 'done' || status === 'made_up' ? 'bg-zinc-900/40' : 'bg-zinc-900'}`}
    >
      <button
        onClick={() => session && setExpanded(!expanded)}
        className="w-full p-4 flex items-center gap-4 text-left"
      >
        {/* Day chip */}
        <div className={`flex-shrink-0 w-12 h-12 rounded-xl flex flex-col items-center justify-center ${
          isToday ? 'bg-emerald-500 text-zinc-950' : 'bg-zinc-800 text-zinc-300'
        }`}>
          <span className="font-mono text-[10px] uppercase font-bold leading-none">{DAY_SHORT_NL[dayInfo.day]}</span>
          <span className="font-display text-lg font-bold leading-none mt-0.5">{new Date(dayInfo.dateObj).getDate()}</span>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-medium truncate ${planned.type === 'rest' ? 'text-zinc-500' : 'text-zinc-100'}`}>
            {getTypeLabel()}
          </p>
          <div className="flex items-center gap-2 mt-1">
            {Icon && <Icon className={`w-3 h-3 ${cfg.textClass}`} />}
            <span className={`text-xs font-mono uppercase tracking-wider ${cfg.textClass}`}>{cfg.label}</span>
            {session && (
              <span className="text-xs text-zinc-500">
                · {session.type === 'strength' ? `${session.exercises?.length || 0} oef` : `${session.duration || 0}min`}
                {' · '}
                <span className="text-emerald-400/80">{calculateCalories(session, bodyWeight)} kcal</span>
              </span>
            )}
          </div>
        </div>

        {/* Action */}
        {(status === 'today' || status === 'missed' || status === 'upcoming') && planned.type !== 'rest' && (
          <button
            onClick={(e) => { e.stopPropagation(); onStartTrain(); }}
            className="flex-shrink-0 px-3 py-2 rounded-lg bg-emerald-500 text-zinc-950 text-xs font-bold uppercase tracking-wider hover:bg-emerald-400 transition"
          >
            Start
          </button>
        )}
        {session && (
          <ChevronDown className={`w-5 h-5 text-zinc-500 transition-transform ${expanded ? 'rotate-180' : ''}`} />
        )}
      </button>

      {/* Expanded session details */}
      {expanded && session && (
        <div className="border-t border-zinc-800 p-4 space-y-3 anim-slide-up">
          {session.date !== dayInfo.date && (
            <p className="text-xs text-emerald-400 font-mono">
              Ingehaald op {formatDate(session.date)}
            </p>
          )}

          {/* Kcal banner */}
          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3 flex items-center gap-3">
            <Flame className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-xs text-zinc-500 font-mono uppercase tracking-wider">Geschatte verbranding</p>
              <p className="font-mono text-base font-bold text-emerald-400">
                ~{calculateCalories(session, bodyWeight)} kcal
                <span className="text-xs text-zinc-500 font-normal ml-2">
                  · {estimateSessionDuration(session)} min
                </span>
              </p>
            </div>
          </div>

          {session.type === 'strength' && session.exercises?.map((ex, i) => (
            <div key={i} className="bg-zinc-950 rounded-lg p-3">
              <p className="text-sm font-semibold mb-2">{ex.name}</p>
              <div className="flex flex-wrap gap-1.5">
                {ex.sets?.map((set, j) => (
                  <span key={j} className="text-xs font-mono px-2 py-1 rounded bg-zinc-900 text-zinc-300">
                    {set.reps}×{set.weight}kg
                  </span>
                ))}
              </div>
            </div>
          ))}
          {session.type === 'cardio' && (
            <div className="bg-zinc-950 rounded-lg p-3 space-y-1">
              {session.duration && <p className="text-sm"><span className="text-zinc-500">Duur:</span> <span className="font-mono">{session.duration} min</span></p>}
              {session.distance && <p className="text-sm"><span className="text-zinc-500">Afstand:</span> <span className="font-mono">{session.distance} km</span></p>}
            </div>
          )}
          {session.notes && (
            <div className="bg-zinc-950 rounded-lg p-3">
              <p className="text-xs text-zinc-500 uppercase tracking-wider font-mono mb-1">Notities</p>
              <p className="text-sm text-zinc-300">{session.notes}</p>
            </div>
          )}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onEditSession(session)}
              className="py-2 rounded-lg bg-zinc-800 text-zinc-300 text-xs uppercase tracking-wider font-medium hover:bg-zinc-700 transition flex items-center justify-center gap-2"
            >
              <Edit2 className="w-3.5 h-3.5" /> Bewerken
            </button>
            <button
              onClick={() => {
                if (confirm('Sessie verwijderen?')) onDeleteSession(session.id);
              }}
              className="py-2 rounded-lg bg-red-500/10 text-red-400 text-xs uppercase tracking-wider font-medium hover:bg-red-500/20 transition flex items-center justify-center gap-2"
            >
              <Trash2 className="w-3.5 h-3.5" /> Verwijderen
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============ TRAIN VIEW ============

function TrainView({ schedule, muscleGroups, sessions, editingSession, onSave, onUpdate, onClearEditing }) {
  const [step, setStep] = useState('select'); // select -> log
  const [sessionData, setSessionData] = useState(null);

  // If we entered with an editingSession, jump straight to log step
  useEffect(() => {
    if (editingSession) {
      // Make sure exercises array is well-formed for the editor
      const data = {
        ...editingSession,
        exercises: editingSession.exercises ? editingSession.exercises.map(ex => ({
          name: ex.name,
          sets: (ex.sets || []).map(s => ({ reps: String(s.reps), weight: String(s.weight) }))
        })) : [],
        duration: editingSession.duration ? String(editingSession.duration) : '',
        distance: editingSession.distance ? String(editingSession.distance) : '',
        notes: editingSession.notes || ''
      };
      setSessionData(data);
      setStep('log');
    }
  }, [editingSession]);

  const todayKey = getDayKey(new Date());
  const todayPlanned = schedule[todayKey];

  const startSession = (config) => {
    setSessionData({
      date: toISODate(new Date()),
      plannedDay: config.plannedDay,
      type: config.type,
      muscleGroup: config.muscleGroup,
      cardioType: config.cardioType,
      name: config.name,
      exercises: config.type === 'strength' ?
        (muscleGroups[config.muscleGroup]?.exercises || []).map(name => ({ name, sets: [] })) : [],
      duration: '',
      distance: '',
      notes: ''
    });
    setStep('log');
  };

  const handleSave = async () => {
    // Validate
    if (sessionData.type === 'strength') {
      const hasAnySet = sessionData.exercises.some(ex => ex.sets.length > 0);
      if (!hasAnySet) { alert('Voeg minstens één set toe.'); return; }
    } else if (sessionData.type === 'cardio') {
      if (!sessionData.duration && !sessionData.distance) {
        alert('Vul duur of afstand in.'); return;
      }
    }
    // Clean up empty sets
    let cleaned = { ...sessionData };
    if (cleaned.type === 'strength') {
      cleaned.exercises = cleaned.exercises
        .map(ex => ({ ...ex, sets: ex.sets.filter(s => s.reps && s.weight) }))
        .filter(ex => ex.sets.length > 0);
    }
    if (cleaned.id) {
      // editing existing session
      await onUpdate(cleaned);
    } else {
      await onSave(cleaned);
    }
    setSessionData(null);
    setStep('select');
    onClearEditing && onClearEditing();
  };

  const handleCancel = () => {
    setSessionData(null);
    setStep('select');
    onClearEditing && onClearEditing();
  };

  if (step === 'log' && sessionData) {
    return (
      <SessionLogger
        sessionData={sessionData}
        setSessionData={setSessionData}
        sessions={sessions}
        isEditing={!!sessionData.id}
        onCancel={handleCancel}
        onSave={handleSave}
      />
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-display text-3xl font-bold">Wat ga je doen?</h2>
        <p className="text-sm text-zinc-500 mt-1">Kies uit je schema of begin een vrije sessie.</p>
      </div>

      {/* Vandaag */}
      {todayPlanned && todayPlanned.type !== 'rest' && (
        <div className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border border-emerald-500/30 rounded-2xl p-5 glow-green">
          <p className="text-xs text-emerald-400 font-mono uppercase tracking-wider mb-1">Vandaag gepland</p>
          <h3 className="font-display text-2xl font-bold">{todayPlanned.name}</h3>
          <button
            onClick={() => startSession({
              plannedDay: todayKey,
              type: todayPlanned.type,
              muscleGroup: todayPlanned.muscleGroup,
              cardioType: todayPlanned.cardioType,
              name: todayPlanned.name
            })}
            className="mt-4 w-full py-3 rounded-xl bg-emerald-500 text-zinc-950 font-bold uppercase tracking-wider hover:bg-emerald-400 transition flex items-center justify-center gap-2"
          >
            <Zap className="w-4 h-4" /> Start training
          </button>
        </div>
      )}

      {/* Of: alle schema dagen */}
      <div>
        <p className="text-xs text-zinc-500 font-mono uppercase tracking-wider mb-3">Inhalen / andere training</p>
        <div className="space-y-2">
          {DAYS.filter(d => schedule[d].type !== 'rest').map(day => {
            const item = schedule[day];
            if (day === todayKey && todayPlanned.type !== 'rest') return null;
            return (
              <button
                key={day}
                onClick={() => startSession({
                  plannedDay: day,
                  type: item.type,
                  muscleGroup: item.muscleGroup,
                  cardioType: item.cardioType,
                  name: item.name
                })}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex items-center gap-3 hover:border-zinc-700 transition text-left"
              >
                <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center font-mono text-xs font-bold uppercase">
                  {DAY_SHORT_NL[day]}
                </div>
                <div className="flex-1">
                  <p className="font-medium">{item.name}</p>
                  <p className="text-xs text-zinc-500 capitalize">
                    {item.type === 'strength' ? 'Krachttraining' : 'Cardio'}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-zinc-600" />
              </button>
            );
          })}
        </div>
      </div>

      {/* Vrije sessie */}
      <div>
        <p className="text-xs text-zinc-500 font-mono uppercase tracking-wider mb-3">Vrije sessie</p>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(muscleGroups).map(([key, group]) => (
            <button
              key={key}
              onClick={() => startSession({
                plannedDay: 'free',
                type: 'strength',
                muscleGroup: key,
                name: group.label
              })}
              className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 hover:border-emerald-500/40 transition text-left"
            >
              <Dumbbell className="w-5 h-5 text-emerald-400 mb-2" />
              <p className="text-sm font-medium">{group.label}</p>
            </button>
          ))}
          {Object.entries(CARDIO_TYPES).map(([key, t]) => (
            <button
              key={key}
              onClick={() => startSession({
                plannedDay: 'free',
                type: 'cardio',
                cardioType: key,
                name: t.label
              })}
              className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 hover:border-emerald-500/40 transition text-left"
            >
              <Heart className="w-5 h-5 text-emerald-400 mb-2" />
              <p className="text-sm font-medium">{t.icon} {t.label}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function SessionLogger({ sessionData, setSessionData, sessions, isEditing, onCancel, onSave }) {
  const updateField = (field, value) => setSessionData({ ...sessionData, [field]: value });

  const updateExercise = (idx, newEx) => {
    const newExercises = [...sessionData.exercises];
    newExercises[idx] = newEx;
    setSessionData({ ...sessionData, exercises: newExercises });
  };

  const addSetToExercise = (idx) => {
    const ex = sessionData.exercises[idx];
    const lastSet = ex.sets[ex.sets.length - 1];
    const newSet = lastSet ? { reps: lastSet.reps, weight: lastSet.weight } : { reps: '', weight: '' };
    updateExercise(idx, { ...ex, sets: [...ex.sets, newSet] });
  };

  const removeSet = (exIdx, setIdx) => {
    const ex = sessionData.exercises[exIdx];
    updateExercise(exIdx, { ...ex, sets: ex.sets.filter((_, i) => i !== setIdx) });
  };

  const updateSet = (exIdx, setIdx, field, value) => {
    const ex = sessionData.exercises[exIdx];
    const newSets = [...ex.sets];
    newSets[setIdx] = { ...newSets[setIdx], [field]: value };
    updateExercise(exIdx, { ...ex, sets: newSets });
  };

  // PR detection: get current PR for each exercise
  const getPR = (exerciseName) => {
    let maxWeight = 0;
    sessions.forEach(s => {
      s.exercises?.forEach(ex => {
        if (ex.name === exerciseName) {
          ex.sets?.forEach(set => {
            const w = parseFloat(set.weight) || 0;
            if (w > maxWeight) maxWeight = w;
          });
        }
      });
    });
    return maxWeight;
  };

  // Find previous similar session (same type + muscle group / cardio type)
  const previousSession = useMemo(() => findPreviousSimilarSession(sessionData, sessions), [sessionData, sessions]);

  // Can copy from previous if it exists AND current sessie heeft geen sets ingevuld
  const currentHasContent = sessionData.type === 'strength'
    ? sessionData.exercises.some(ex => ex.sets.length > 0)
    : (sessionData.duration || sessionData.distance);
  const canCopyPrevious = previousSession && !currentHasContent && !isEditing;

  const copyFromPrevious = () => {
    if (!previousSession) return;
    if (previousSession.type === 'strength') {
      // Map vorige oefeningen op huidige oefeningen-template (op naam)
      const newExercises = sessionData.exercises.map(ex => {
        const prevEx = previousSession.exercises?.find(pe => pe.name === ex.name);
        if (prevEx && prevEx.sets) {
          return {
            name: ex.name,
            sets: prevEx.sets.map(s => ({ reps: String(s.reps), weight: String(s.weight) }))
          };
        }
        return ex;
      });
      // Voeg ook oefeningen toe die in vorige sessie zaten maar niet in huidige template
      previousSession.exercises?.forEach(prevEx => {
        if (!newExercises.find(ex => ex.name === prevEx.name)) {
          newExercises.push({
            name: prevEx.name,
            sets: prevEx.sets.map(s => ({ reps: String(s.reps), weight: String(s.weight) }))
          });
        }
      });
      setSessionData({ ...sessionData, exercises: newExercises });
    } else if (previousSession.type === 'cardio') {
      setSessionData({
        ...sessionData,
        duration: previousSession.duration ? String(previousSession.duration) : '',
        distance: previousSession.distance ? String(previousSession.distance) : ''
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={onCancel} className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-800">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h2 className="font-display text-2xl font-bold leading-tight">{sessionData.name}</h2>
            {isEditing && (
              <span className="px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-400 text-[10px] font-bold uppercase tracking-wider">
                Bewerken
              </span>
            )}
          </div>
          <p className="text-xs text-zinc-500 font-mono uppercase tracking-wider">
            {sessionData.plannedDay !== 'free' ? `${DAY_LABELS_NL[sessionData.plannedDay]}-training` : 'Vrije sessie'}
          </p>
        </div>
      </div>

      {/* Copy previous session */}
      {canCopyPrevious && (
        <button
          onClick={copyFromPrevious}
          className="w-full bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3 flex items-center gap-3 hover:bg-emerald-500/15 active:bg-emerald-500/20 transition text-left"
        >
          <div className="w-9 h-9 rounded-lg bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
            <RotateCcw className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-emerald-400">Vorige sessie kopiëren</p>
            <p className="text-xs text-zinc-400">
              {(() => {
                const dys = daysBetween(previousSession.date, sessionData.date);
                if (dys === 0) return 'Eerder vandaag';
                if (dys === 1) return 'Gisteren';
                if (dys <= 7) return `${dys} dagen geleden`;
                return formatDate(previousSession.date);
              })()}
              {previousSession.type === 'strength' && ` · ${previousSession.exercises?.length || 0} oef`}
            </p>
          </div>
          <ChevronRight className="w-5 h-5 text-emerald-400 flex-shrink-0" />
        </button>
      )}

      {/* Date selector */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
        <label className="text-xs text-zinc-500 font-mono uppercase tracking-wider">Datum</label>
        <input
          type="date"
          value={sessionData.date}
          onChange={e => updateField('date', e.target.value)}
          className="w-full mt-1 bg-transparent text-zinc-100 font-medium outline-none text-base"
        />
      </div>

      {/* Strength: exercises */}
      {sessionData.type === 'strength' && (
        <div className="space-y-3">
          {sessionData.exercises.map((ex, exIdx) => {
            const pr = getPR(ex.name);
            const currentMax = Math.max(0, ...ex.sets.map(s => parseFloat(s.weight) || 0));
            const isPR = currentMax > pr && currentMax > 0;
            return (
              <div key={exIdx} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 flex-1">
                    <h3 className="font-display text-lg font-bold">{ex.name}</h3>
                    {isPR && (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                        <Trophy className="w-3 h-3" /> PR!
                      </span>
                    )}
                  </div>
                  {pr > 0 && (
                    <span className="text-xs text-zinc-500 font-mono">PR: {pr}kg</span>
                  )}
                </div>

                {ex.sets.length > 0 && (
                  <div className="space-y-2 mb-3">
                    <div className="grid grid-cols-[32px_1fr_1.4fr_28px] gap-2 text-[10px] font-mono uppercase tracking-wider text-zinc-500 px-1">
                      <span>Set</span>
                      <span className="text-center">Reps</span>
                      <span className="text-center">Gewicht (kg)</span>
                      <span></span>
                    </div>
                    {ex.sets.map((set, setIdx) => (
                      <div key={setIdx} className="grid grid-cols-[32px_1fr_1.4fr_28px] gap-2 items-center">
                        <span className="font-mono text-base font-bold text-emerald-400 text-center">#{setIdx + 1}</span>
                        <input
                          type="number"
                          inputMode="numeric"
                          value={set.reps}
                          onChange={e => updateSet(exIdx, setIdx, 'reps', e.target.value)}
                          placeholder="0"
                          className="bg-zinc-950 border border-zinc-800 rounded-lg px-2 py-3 text-center font-mono text-base focus:border-emerald-500 focus:bg-zinc-900 outline-none min-w-0"
                        />
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              const cur = parseFloat(set.weight) || 0;
                              const next = Math.max(0, cur - 2.5);
                              updateSet(exIdx, setIdx, 'weight', String(next));
                            }}
                            className="flex-shrink-0 w-8 h-11 rounded-lg bg-zinc-800 text-zinc-300 font-mono font-bold text-base hover:bg-zinc-700 active:bg-zinc-600 transition flex items-center justify-center"
                            aria-label="Min 2.5kg"
                          >−</button>
                          <input
                            type="number"
                            inputMode="decimal"
                            step="0.5"
                            value={set.weight}
                            onChange={e => updateSet(exIdx, setIdx, 'weight', e.target.value)}
                            placeholder="0"
                            className="flex-1 min-w-0 bg-zinc-950 border border-zinc-800 rounded-lg px-2 py-3 text-center font-mono text-base focus:border-emerald-500 focus:bg-zinc-900 outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              const cur = parseFloat(set.weight) || 0;
                              const next = cur + 2.5;
                              updateSet(exIdx, setIdx, 'weight', String(next));
                            }}
                            className="flex-shrink-0 w-8 h-11 rounded-lg bg-zinc-800 text-zinc-300 font-mono font-bold text-base hover:bg-zinc-700 active:bg-zinc-600 transition flex items-center justify-center"
                            aria-label="Plus 2.5kg"
                          >+</button>
                        </div>
                        <button onClick={() => removeSet(exIdx, setIdx)} className="text-zinc-600 hover:text-red-400 p-1">
                          <X className="w-4 h-4 mx-auto" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <button
                  onClick={() => addSetToExercise(exIdx)}
                  className="w-full py-2.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-sm font-medium text-zinc-300 transition flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" /> Set toevoegen
                </button>
              </div>
            );
          })}

          {sessionData.exercises.length === 0 && (
            <div className="bg-zinc-900 border border-dashed border-zinc-800 rounded-xl p-6 text-center text-sm text-zinc-500">
              Geen oefeningen ingesteld voor deze spiergroep.
              <br />Voeg ze toe in tabblad "Beheer".
            </div>
          )}
        </div>
      )}

      {/* Cardio fields */}
      {sessionData.type === 'cardio' && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 space-y-4">
          <div>
            <label className="text-xs text-zinc-500 font-mono uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
              <Clock className="w-3 h-3" /> Duur (minuten)
            </label>
            <input
              type="number"
              inputMode="numeric"
              value={sessionData.duration}
              onChange={e => updateField('duration', e.target.value)}
              placeholder="bv. 30"
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 font-mono text-lg focus:border-emerald-500 outline-none"
            />
          </div>
          <div>
            <label className="text-xs text-zinc-500 font-mono uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
              <MapPin className="w-3 h-3" /> Afstand (km)
            </label>
            <input
              type="number"
              inputMode="decimal"
              step="0.1"
              value={sessionData.distance}
              onChange={e => updateField('distance', e.target.value)}
              placeholder="bv. 5.2"
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 font-mono text-lg focus:border-emerald-500 outline-none"
            />
          </div>
        </div>
      )}

      {/* Strength: optional duration */}
      {sessionData.type === 'strength' && sessionData.exercises.length > 0 && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4">
          <label className="text-xs text-zinc-500 font-mono uppercase tracking-wider flex items-center gap-1.5 mb-1.5">
            <Clock className="w-3 h-3" /> Duur (minuten) <span className="text-zinc-600 normal-case text-[10px]">— optioneel, voor kcal-schatting</span>
          </label>
          <input
            type="number"
            inputMode="numeric"
            value={sessionData.duration}
            onChange={e => updateField('duration', e.target.value)}
            placeholder="laat leeg voor automatische schatting"
            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 font-mono text-base focus:border-emerald-500 outline-none"
          />
        </div>
      )}

      {/* Notes */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4">
        <label className="text-xs text-zinc-500 font-mono uppercase tracking-wider flex items-center gap-1.5 mb-2">
          <FileText className="w-3 h-3" /> Notities
        </label>
        <textarea
          value={sessionData.notes}
          onChange={e => updateField('notes', e.target.value)}
          placeholder="Hoe voelde het? Energie, blessures, observaties..."
          rows={3}
          className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2.5 text-base focus:border-emerald-500 outline-none resize-none"
        />
      </div>

      {/* Save bar */}
      <div className="grid grid-cols-[1fr_2fr] gap-2 sticky bottom-24">
        <button
          onClick={onCancel}
          className="py-4 rounded-xl bg-zinc-800 text-zinc-300 font-bold uppercase tracking-wider text-sm hover:bg-zinc-700 transition"
        >
          Annuleer
        </button>
        <button
          onClick={onSave}
          className="py-4 rounded-xl bg-emerald-500 text-zinc-950 font-bold uppercase tracking-wider text-sm hover:bg-emerald-400 transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
        >
          <Save className="w-4 h-4" /> {isEditing ? 'Wijzigingen opslaan' : 'Sessie opslaan'}
        </button>
      </div>
    </div>
  );
}

// ============ STATS VIEW ============

function StatsView({ sessions, schedule, muscleGroups, bodyWeights, onAddWeight, onDeleteWeight }) {
  const [subTab, setSubTab] = useState('overview'); // overview, weight, exercises

  const bodyWeight = getCurrentBodyWeight(bodyWeights);
  const totalSessions = sessions.length;
  const totalVolume = sessions.reduce((sum, s) => {
    if (s.type !== 'strength') return sum;
    return sum + (s.exercises?.reduce((exSum, ex) =>
      exSum + (ex.sets?.reduce((setSum, set) =>
        setSum + ((parseFloat(set.reps) || 0) * (parseFloat(set.weight) || 0)), 0) || 0), 0) || 0);
  }, 0);
  const totalCardioMinutes = sessions
    .filter(s => s.type === 'cardio')
    .reduce((sum, s) => sum + (parseFloat(s.duration) || 0), 0);
  const totalCalories = sessions.reduce((sum, s) => sum + calculateCalories(s, bodyWeight), 0);

  // Week kcal (current week only)
  const thisWeekStart = getMondayOfWeek(new Date());
  const thisWeekEnd = addDays(thisWeekStart, 6);
  const thisWeekStartStr = toISODate(thisWeekStart);
  const thisWeekEndStr = toISODate(thisWeekEnd);
  const weekCalories = sessions
    .filter(s => s.date >= thisWeekStartStr && s.date <= thisWeekEndStr)
    .reduce((sum, s) => sum + calculateCalories(s, bodyWeight), 0);

  // PRs by exercise
  const prs = useMemo(() => {
    const map = {};
    sessions.forEach(s => {
      s.exercises?.forEach(ex => {
        ex.sets?.forEach(set => {
          const w = parseFloat(set.weight) || 0;
          if (!map[ex.name] || w > map[ex.name].weight) {
            map[ex.name] = { weight: w, reps: parseInt(set.reps) || 0, date: s.date };
          }
        });
      });
    });
    return Object.entries(map).filter(([, v]) => v.weight > 0).sort((a, b) => b[1].weight - a[1].weight);
  }, [sessions]);

  // Kcal per spiergroep / cardio type (aggregate)
  const caloriesByActivity = useMemo(() => {
    const map = {};
    sessions.forEach(s => {
      let key;
      if (s.type === 'strength') {
        key = `🏋 ${muscleGroups[s.muscleGroup]?.label || s.muscleGroup || 'Krachttraining'}`;
      } else if (s.type === 'cardio') {
        const t = CARDIO_TYPES[s.cardioType];
        key = `${t?.icon || '💨'} ${t?.label || 'Cardio'}`;
      } else return;
      const kcal = calculateCalories(s, bodyWeight);
      if (!map[key]) map[key] = { kcal: 0, sessions: 0 };
      map[key].kcal += kcal;
      map[key].sessions += 1;
    });
    return Object.entries(map).sort((a, b) => b[1].kcal - a[1].kcal);
  }, [sessions, muscleGroups, bodyWeight]);

  const exportCSV = () => {
    const rows = [['Datum', 'Type', 'Naam', 'Oefening', 'Set', 'Reps', 'Gewicht (kg)', 'Duur (min)', 'Afstand (km)', 'Kcal', 'Lichaamsgewicht (kg)', 'Lichaamsvet (%)', 'Notities']];
    sessions.forEach(s => {
      const kcal = calculateCalories(s, bodyWeight);
      if (s.type === 'strength') {
        if (!s.exercises || s.exercises.length === 0) {
          rows.push([s.date, 'kracht', s.name || '', '', '', '', '', s.duration || '', '', kcal, '', '', s.notes || '']);
        }
        s.exercises?.forEach(ex => {
          ex.sets?.forEach((set, i) => {
            rows.push([s.date, 'kracht', s.name || '', ex.name, i + 1, set.reps, set.weight, s.duration || '', '', kcal, '', '', s.notes || '']);
          });
        });
      } else if (s.type === 'cardio') {
        rows.push([s.date, 'cardio', s.name || '', '', '', '', '', s.duration || '', s.distance || '', kcal, '', '', s.notes || '']);
      }
    });
    bodyWeights.forEach(w => {
      rows.push([w.date, 'meting', '', '', '', '', '', '', '', '', w.weight ?? '', w.bodyFat ?? '', '']);
    });

    const csv = rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `forge-export-${toISODate(new Date())}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      {/* Sub tabs */}
      <div className="flex gap-2 overflow-x-auto scrollbar-hide -mx-4 px-4">
        {[
          { id: 'overview', label: 'Overzicht' },
          { id: 'weight', label: 'Gewicht' },
          { id: 'exercises', label: 'Oefeningen' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setSubTab(t.id)}
            className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition ${
              subTab === t.id
                ? 'bg-emerald-500 text-zinc-950'
                : 'bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-zinc-200'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {subTab === 'overview' && (
        <>
          {/* Big stats */}
          <div className="grid grid-cols-2 gap-2.5">
            <StatCard label="Sessies" value={totalSessions} icon={Activity} />
            <StatCard label="Streak (weken)" value={calculateStreak(sessions, schedule)} icon={Flame} accent />
            <StatCard label="Kcal deze week" value={weekCalories.toLocaleString('nl-NL')} unit="kcal" icon={Flame} accent />
            <StatCard label="Kcal totaal" value={totalCalories.toLocaleString('nl-NL')} unit="kcal" icon={Flame} />
            <StatCard label="Volume" value={`${Math.round(totalVolume).toLocaleString('nl-NL')}`} unit="kg" icon={TrendingUp} />
            <StatCard label="Cardio" value={Math.round(totalCardioMinutes)} unit="min" icon={Heart} />
          </div>

          {/* Recent activity chart */}
          <ActivityChart sessions={sessions} />

          {/* Calorieën per activiteit */}
          {caloriesByActivity.length > 0 && (
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-emerald-400" />
                  <h3 className="font-display text-lg font-bold">Kcal per activiteit</h3>
                </div>
                <span className="text-[10px] text-zinc-600 font-mono uppercase tracking-wider">totaal</span>
              </div>
              <div className="space-y-2.5">
                {caloriesByActivity.map(([name, data]) => {
                  const maxKcal = caloriesByActivity[0][1].kcal;
                  const pct = maxKcal > 0 ? (data.kcal / maxKcal) * 100 : 0;
                  return (
                    <div key={name}>
                      <div className="flex items-center justify-between text-sm mb-1">
                        <span className="font-medium">{name}</span>
                        <span className="font-mono text-emerald-400 font-bold">
                          {data.kcal.toLocaleString('nl-NL')}
                          <span className="text-xs text-zinc-500 font-normal ml-1">kcal · {data.sessions}×</span>
                        </span>
                      </div>
                      <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-400 rounded-full transition-all" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
              <p className="text-[10px] text-zinc-600 font-mono mt-3">
                Schatting o.b.v. MET-waarden bij {bodyWeight}kg lichaamsgewicht
              </p>
            </div>
          )}

          {/* PRs */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-emerald-400" />
                <h3 className="font-display text-lg font-bold">Personal Records</h3>
              </div>
            </div>
            {prs.length === 0 ? (
              <p className="text-sm text-zinc-500">Nog geen PRs. Log je eerste sessie om te beginnen!</p>
            ) : (
              <div className="space-y-2">
                {prs.slice(0, 10).map(([name, pr]) => (
                  <div key={name} className="flex items-center justify-between py-2 border-b border-zinc-800/60 last:border-0">
                    <span className="text-sm font-medium">{name}</span>
                    <div className="text-right">
                      <span className="font-mono text-sm font-bold text-emerald-400">{pr.weight}kg</span>
                      <span className="text-xs text-zinc-500 ml-2">×{pr.reps}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Export */}
          <button
            onClick={exportCSV}
            className="w-full py-4 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-emerald-500/30 hover:bg-zinc-900/80 transition flex items-center justify-center gap-2 font-medium"
          >
            <Download className="w-4 h-4" /> Exporteer alles als CSV
          </button>
        </>
      )}

      {subTab === 'weight' && (
        <BodyWeightView weights={bodyWeights} onAdd={onAddWeight} onDelete={onDeleteWeight} />
      )}

      {subTab === 'exercises' && (
        <ExerciseProgressView sessions={sessions} muscleGroups={muscleGroups} />
      )}
    </div>
  );
}

function StatCard({ label, value, unit, icon: Icon, accent }) {
  return (
    <div className={`rounded-2xl p-4 border ${accent ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-zinc-900 border-zinc-800'}`}>
      <div className="flex items-center gap-1.5 mb-2">
        <Icon className={`w-3.5 h-3.5 ${accent ? 'text-emerald-400' : 'text-zinc-500'}`} />
        <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-mono">{label}</span>
      </div>
      <p className="font-display text-3xl font-bold leading-none">
        {value}
        {unit && <span className="text-sm text-zinc-500 ml-1.5 font-normal font-mono">{unit}</span>}
      </p>
    </div>
  );
}

function ActivityChart({ sessions }) {
  // Last 8 weeks of activity
  const data = useMemo(() => {
    const weeks = [];
    const now = new Date();
    for (let i = 7; i >= 0; i--) {
      const monday = getMondayOfWeek(addDays(now, -i * 7));
      const mondayStr = toISODate(monday);
      const sundayStr = toISODate(addDays(monday, 6));
      const weekSessions = sessions.filter(s => s.date >= mondayStr && s.date <= sundayStr);
      weeks.push({
        week: formatDate(monday).split(' ')[0],
        kracht: weekSessions.filter(s => s.type === 'strength').length,
        cardio: weekSessions.filter(s => s.type === 'cardio').length
      });
    }
    return weeks;
  }, [sessions]);

  const maxValue = Math.max(...data.map(d => d.kracht + d.cardio), 4);

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Activity className="w-5 h-5 text-emerald-400" />
        <h3 className="font-display text-lg font-bold">Activiteit (8 weken)</h3>
      </div>
      <div className="h-40">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} barSize={20}>
            <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
            <XAxis dataKey="week" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
            <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} domain={[0, Math.ceil(maxValue)]} allowDecimals={false} />
            <Tooltip
              contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px', fontSize: '12px' }}
              cursor={{ fill: 'rgba(74, 222, 128, 0.05)' }}
            />
            <Bar dataKey="kracht" stackId="a" fill="#4ade80" radius={[0, 0, 0, 0]} />
            <Bar dataKey="cardio" stackId="a" fill="#22d3ee" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="flex items-center gap-4 mt-2 text-xs">
        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-400" /> <span className="text-zinc-400">Kracht</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-cyan-400" /> <span className="text-zinc-400">Cardio</span></div>
      </div>
    </div>
  );
}

function BodyWeightView({ weights, onAdd, onDelete }) {
  const [date, setDate] = useState(toISODate(new Date()));
  const [weight, setWeight] = useState('');
  const [bodyFat, setBodyFat] = useState('');

  const submit = async () => {
    const hasWeight = weight && !isNaN(parseFloat(weight));
    const hasFat = bodyFat && !isNaN(parseFloat(bodyFat));
    if (!hasWeight && !hasFat) {
      alert('Voer minimaal gewicht of vetpercentage in');
      return;
    }
    const entry = { date };
    if (hasWeight) entry.weight = parseFloat(weight);
    if (hasFat) entry.bodyFat = parseFloat(bodyFat);
    await onAdd(entry);
    setWeight('');
    setBodyFat('');
  };

  const weightData = weights.filter(w => w.weight != null).map(w => ({ date: w.date, weight: w.weight, label: formatDate(w.date) }));
  const fatData = weights.filter(w => w.bodyFat != null).map(w => ({ date: w.date, bodyFat: w.bodyFat, label: formatDate(w.date) }));

  const latestWeight = [...weightData].reverse()[0];
  const firstWeight = weightData[0];
  const weightChange = latestWeight && firstWeight && latestWeight.date !== firstWeight.date
    ? (latestWeight.weight - firstWeight.weight).toFixed(1) : null;

  const latestFat = [...fatData].reverse()[0];
  const firstFat = fatData[0];
  const fatChange = latestFat && firstFat && latestFat.date !== firstFat.date
    ? (latestFat.bodyFat - firstFat.bodyFat).toFixed(1) : null;

  return (
    <div className="space-y-5">
      {/* Add new */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
        <div className="flex items-center gap-2 mb-3">
          <Scale className="w-5 h-5 text-emerald-400" />
          <h3 className="font-display text-lg font-bold">Meting toevoegen</h3>
        </div>
        <div className="space-y-2">
          <input
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-3 text-base focus:border-emerald-500 outline-none"
          />
          <div className="grid grid-cols-2 gap-2">
            <div className="relative">
              <label className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider absolute -top-2 left-3 bg-zinc-900 px-1">Gewicht</label>
              <input
                type="number"
                inputMode="decimal"
                step="0.1"
                value={weight}
                onChange={e => setWeight(e.target.value)}
                placeholder="80.5"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-3 font-mono text-base focus:border-emerald-500 outline-none pr-9"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-600 font-mono">kg</span>
            </div>
            <div className="relative">
              <label className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider absolute -top-2 left-3 bg-zinc-900 px-1">Lichaamsvet</label>
              <input
                type="number"
                inputMode="decimal"
                step="0.1"
                value={bodyFat}
                onChange={e => setBodyFat(e.target.value)}
                placeholder="18.5"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-3 font-mono text-base focus:border-emerald-500 outline-none pr-9"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-600 font-mono">%</span>
            </div>
          </div>
          <button
            onClick={submit}
            className="w-full py-3 rounded-lg bg-emerald-500 text-zinc-950 font-bold uppercase tracking-wider text-sm hover:bg-emerald-400 transition flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" /> Meting toevoegen
          </button>
        </div>
        <p className="text-xs text-zinc-600 mt-2">Tip: vul alleen in wat je gemeten hebt – beide hoeven niet.</p>
      </div>

      {/* Weight stats */}
      {latestWeight && (
        <div>
          <p className="text-xs text-zinc-500 font-mono uppercase tracking-wider mb-2">Gewicht</p>
          <div className="grid grid-cols-3 gap-2.5">
            <StatCard label="Huidig" value={latestWeight.weight} unit="kg" icon={Scale} accent />
            {firstWeight && firstWeight.date !== latestWeight.date && (
              <>
                <StatCard label="Start" value={firstWeight.weight} unit="kg" icon={Target} />
                <StatCard label="Verschil" value={weightChange > 0 ? `+${weightChange}` : weightChange} unit="kg" icon={TrendingUp} />
              </>
            )}
          </div>
        </div>
      )}

      {/* Weight chart */}
      {weightData.length >= 2 && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
          <h3 className="font-display text-lg font-bold mb-4">Gewicht verloop</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weightData} margin={{ left: -10, right: 5, top: 5 }}>
                <defs>
                  <linearGradient id="weightGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#4ade80" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="#4ade80" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis dataKey="label" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} domain={['dataMin - 1', 'dataMax + 1']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(value) => [`${value} kg`, 'Gewicht']}
                />
                <Area type="monotone" dataKey="weight" stroke="#4ade80" strokeWidth={2} fill="url(#weightGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Body fat stats */}
      {latestFat && (
        <div>
          <p className="text-xs text-zinc-500 font-mono uppercase tracking-wider mb-2">Lichaamsvet</p>
          <div className="grid grid-cols-3 gap-2.5">
            <StatCard label="Huidig" value={latestFat.bodyFat} unit="%" icon={Activity} accent />
            {firstFat && firstFat.date !== latestFat.date && (
              <>
                <StatCard label="Start" value={firstFat.bodyFat} unit="%" icon={Target} />
                <StatCard label="Verschil" value={fatChange > 0 ? `+${fatChange}` : fatChange} unit="%" icon={TrendingUp} />
              </>
            )}
          </div>
        </div>
      )}

      {/* Body fat chart */}
      {fatData.length >= 2 && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
          <h3 className="font-display text-lg font-bold mb-4">Vet% verloop</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={fatData} margin={{ left: -10, right: 5, top: 5 }}>
                <defs>
                  <linearGradient id="fatGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#22d3ee" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="#22d3ee" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis dataKey="label" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} domain={['dataMin - 1', 'dataMax + 1']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(value) => [`${value} %`, 'Vet']}
                />
                <Area type="monotone" dataKey="bodyFat" stroke="#22d3ee" strokeWidth={2} fill="url(#fatGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* History */}
      {weights.length > 0 && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
          <h3 className="font-display text-lg font-bold mb-3">Historie</h3>
          <div className="space-y-1 max-h-80 overflow-y-auto">
            {[...weights].reverse().map(w => (
              <div key={w.date} className="flex items-center justify-between py-2 border-b border-zinc-800/60 last:border-0">
                <span className="text-sm text-zinc-400 font-mono">{formatDate(w.date)}</span>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-3 text-right">
                    {w.weight != null && (
                      <span className="font-mono text-sm font-bold text-emerald-400">{w.weight} kg</span>
                    )}
                    {w.bodyFat != null && (
                      <span className="font-mono text-sm font-bold text-cyan-400">{w.bodyFat}%</span>
                    )}
                  </div>
                  <button onClick={() => { if (confirm('Verwijderen?')) onDelete(w.date); }} className="text-zinc-600 hover:text-red-400">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ExerciseProgressView({ sessions, muscleGroups }) {
  const allExercises = useMemo(() => {
    const set = new Set();
    sessions.forEach(s => s.exercises?.forEach(ex => set.add(ex.name)));
    return Array.from(set).sort();
  }, [sessions]);

  const [selected, setSelected] = useState(allExercises[0] || null);

  useEffect(() => {
    if (!selected && allExercises.length > 0) setSelected(allExercises[0]);
  }, [allExercises, selected]);

  const exerciseData = useMemo(() => {
    if (!selected) return [];
    const points = [];
    sessions.forEach(s => {
      s.exercises?.forEach(ex => {
        if (ex.name === selected) {
          const maxWeight = Math.max(0, ...ex.sets.map(set => parseFloat(set.weight) || 0));
          const totalVolume = ex.sets.reduce((sum, set) =>
            sum + ((parseFloat(set.reps) || 0) * (parseFloat(set.weight) || 0)), 0);
          points.push({
            date: s.date,
            label: formatDate(s.date),
            maxWeight,
            volume: Math.round(totalVolume)
          });
        }
      });
    });
    return points.sort((a, b) => a.date.localeCompare(b.date));
  }, [selected, sessions]);

  if (allExercises.length === 0) {
    return (
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 text-center">
        <Dumbbell className="w-10 h-10 text-zinc-700 mx-auto mb-3" />
        <p className="text-sm text-zinc-500">
          Nog geen oefeningen gelogd. Begin een sessie in tabblad "Train".
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs text-zinc-500 font-mono uppercase tracking-wider mb-2 block">Oefening</label>
        <select
          value={selected || ''}
          onChange={e => setSelected(e.target.value)}
          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 font-medium focus:border-emerald-500 outline-none"
        >
          {allExercises.map(name => (
            <option key={name} value={name}>{name}</option>
          ))}
        </select>
      </div>

      {exerciseData.length > 0 && (
        <>
          <div className="grid grid-cols-2 gap-2.5">
            <StatCard
              label="Max gewicht"
              value={Math.max(...exerciseData.map(d => d.maxWeight))}
              unit="kg"
              icon={Trophy}
              accent
            />
            <StatCard
              label="Totaal sessies"
              value={exerciseData.length}
              icon={Activity}
            />
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
            <h3 className="font-display text-lg font-bold mb-4">Max gewicht per sessie</h3>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={exerciseData} margin={{ left: -10, right: 5, top: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                  <XAxis dataKey="label" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px', fontSize: '12px' }}
                    formatter={(value) => [`${value} kg`, 'Max']}
                  />
                  <Line type="monotone" dataKey="maxWeight" stroke="#4ade80" strokeWidth={2.5} dot={{ fill: '#4ade80', r: 4 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
            <h3 className="font-display text-lg font-bold mb-4">Volume per sessie</h3>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={exerciseData} margin={{ left: -10, right: 5, top: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                  <XAxis dataKey="label" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px', fontSize: '12px' }}
                    formatter={(value) => [`${value} kg`, 'Volume']}
                    cursor={{ fill: 'rgba(74, 222, 128, 0.05)' }}
                  />
                  <Bar dataKey="volume" fill="#4ade80" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ============ MANAGE VIEW ============

function ManageView({ schedule, muscleGroups, onUpdateSchedule, onUpdateMuscleGroups }) {
  const [subTab, setSubTab] = useState('schedule');

  return (
    <div className="space-y-5">
      <div className="flex gap-2">
        {[
          { id: 'schedule', label: 'Schema' },
          { id: 'exercises', label: 'Oefeningen' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setSubTab(t.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition ${
              subTab === t.id
                ? 'bg-emerald-500 text-zinc-950'
                : 'bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-zinc-200'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {subTab === 'schedule' && (
        <ScheduleEditor schedule={schedule} muscleGroups={muscleGroups} onUpdate={onUpdateSchedule} />
      )}
      {subTab === 'exercises' && (
        <ExerciseEditor muscleGroups={muscleGroups} onUpdate={onUpdateMuscleGroups} />
      )}
    </div>
  );
}

function ScheduleEditor({ schedule, muscleGroups, onUpdate }) {
  const [draft, setDraft] = useState(schedule);
  const [dirty, setDirty] = useState(false);

  const updateDay = (day, changes) => {
    setDraft({ ...draft, [day]: { ...draft[day], ...changes } });
    setDirty(true);
  };

  const save = () => { onUpdate(draft); setDirty(false); };
  const reset = () => { setDraft(schedule); setDirty(false); };

  return (
    <div className="space-y-3">
      <p className="text-sm text-zinc-400">Pas je vaste weekschema aan. Per dag kies je krachttraining, cardio of rust.</p>

      {DAYS.map(day => {
        const item = draft[day];
        return (
          <div key={day} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center font-mono text-xs font-bold">
                {DAY_SHORT_NL[day]}
              </div>
              <h3 className="font-display text-lg font-bold">{DAY_LABELS_NL[day]}</h3>
            </div>

            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'strength', label: 'Kracht', icon: Dumbbell },
                { id: 'cardio', label: 'Cardio', icon: Heart },
                { id: 'rest', label: 'Rust', icon: Clock }
              ].map(opt => {
                const Icon = opt.icon;
                const active = item.type === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => updateDay(day, { type: opt.id })}
                    className={`py-2.5 rounded-lg text-xs font-medium uppercase tracking-wider transition flex flex-col items-center gap-1 ${
                      active
                        ? 'bg-emerald-500 text-zinc-950'
                        : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {opt.label}
                  </button>
                );
              })}
            </div>

            {item.type === 'strength' && (
              <select
                value={item.muscleGroup || ''}
                onChange={e => {
                  const mg = e.target.value;
                  updateDay(day, { muscleGroup: mg, name: muscleGroups[mg]?.label || '' });
                }}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2.5 text-base focus:border-emerald-500 outline-none"
              >
                <option value="">– kies spiergroep –</option>
                {Object.entries(muscleGroups).map(([key, g]) => (
                  <option key={key} value={key}>{g.label}</option>
                ))}
              </select>
            )}
            {item.type === 'cardio' && (
              <select
                value={item.cardioType || ''}
                onChange={e => {
                  const ct = e.target.value;
                  updateDay(day, { cardioType: ct, name: CARDIO_TYPES[ct]?.label || '' });
                }}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2.5 text-base focus:border-emerald-500 outline-none"
              >
                <option value="">– kies type –</option>
                {Object.entries(CARDIO_TYPES).map(([key, t]) => (
                  <option key={key} value={key}>{t.icon} {t.label}</option>
                ))}
              </select>
            )}
            {item.type !== 'rest' && (
              <input
                type="text"
                value={item.name || ''}
                onChange={e => updateDay(day, { name: e.target.value })}
                placeholder="Naam (bv. 'Borst zwaar')"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2.5 text-base focus:border-emerald-500 outline-none"
              />
            )}
            {item.type === 'rest' && (
              <input
                type="text"
                value={item.name || ''}
                onChange={e => updateDay(day, { name: e.target.value })}
                placeholder="Optioneel: 'Rust (school)'"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2.5 text-base focus:border-emerald-500 outline-none"
              />
            )}
          </div>
        );
      })}

      {dirty && (
        <div className="grid grid-cols-2 gap-2 sticky bottom-24 z-10">
          <button onClick={reset} className="py-3 rounded-xl bg-zinc-800 text-zinc-300 font-bold uppercase tracking-wider text-sm">
            Annuleer
          </button>
          <button onClick={save} className="py-3 rounded-xl bg-emerald-500 text-zinc-950 font-bold uppercase tracking-wider text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20">
            <Save className="w-4 h-4" /> Opslaan
          </button>
        </div>
      )}
    </div>
  );
}

function ExerciseEditor({ muscleGroups, onUpdate }) {
  const [editing, setEditing] = useState(null);
  const [newName, setNewName] = useState('');
  const [newGroupKey, setNewGroupKey] = useState('');
  const [newGroupLabel, setNewGroupLabel] = useState('');
  const [showAddGroup, setShowAddGroup] = useState(false);

  const addExercise = (groupKey, name) => {
    if (!name.trim()) return;
    const newGroups = { ...muscleGroups };
    newGroups[groupKey] = {
      ...newGroups[groupKey],
      exercises: [...(newGroups[groupKey].exercises || []), name.trim()]
    };
    onUpdate(newGroups);
  };

  const removeExercise = (groupKey, idx) => {
    const newGroups = { ...muscleGroups };
    newGroups[groupKey] = {
      ...newGroups[groupKey],
      exercises: newGroups[groupKey].exercises.filter((_, i) => i !== idx)
    };
    onUpdate(newGroups);
  };

  const addGroup = () => {
    if (!newGroupLabel.trim()) return;
    const key = newGroupLabel.toLowerCase().replace(/[^a-z0-9]+/g, '_');
    if (muscleGroups[key]) { alert('Spiergroep bestaat al'); return; }
    onUpdate({ ...muscleGroups, [key]: { label: newGroupLabel.trim(), exercises: [] } });
    setNewGroupLabel('');
    setShowAddGroup(false);
  };

  const removeGroup = (key) => {
    if (!confirm(`Spiergroep "${muscleGroups[key].label}" verwijderen?`)) return;
    const newGroups = { ...muscleGroups };
    delete newGroups[key];
    onUpdate(newGroups);
  };

  return (
    <div className="space-y-3">
      <p className="text-sm text-zinc-400">Beheer je oefeningen per spiergroep. Bij het loggen krijg je deze automatisch te zien.</p>

      {Object.entries(muscleGroups).map(([key, group]) => (
        <div key={key} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-display text-lg font-bold">{group.label}</h3>
            <button onClick={() => removeGroup(key)} className="text-zinc-600 hover:text-red-400 text-xs uppercase tracking-wider">
              Verwijder groep
            </button>
          </div>
          <div className="space-y-1.5 mb-3">
            {(group.exercises || []).map((ex, i) => (
              <div key={i} className="flex items-center justify-between py-2 px-3 bg-zinc-950 rounded-lg">
                <span className="text-sm">{ex}</span>
                <button onClick={() => removeExercise(key, i)} className="text-zinc-600 hover:text-red-400">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
            {(!group.exercises || group.exercises.length === 0) && (
              <p className="text-sm text-zinc-600 italic px-3">Geen oefeningen</p>
            )}
          </div>
          <ExerciseAddRow onAdd={(name) => addExercise(key, name)} />
        </div>
      ))}

      {!showAddGroup ? (
        <button
          onClick={() => setShowAddGroup(true)}
          className="w-full py-4 rounded-2xl bg-zinc-900 border border-dashed border-zinc-700 hover:border-emerald-500/40 transition flex items-center justify-center gap-2 text-zinc-400 hover:text-emerald-400"
        >
          <Plus className="w-4 h-4" /> Nieuwe spiergroep
        </button>
      ) : (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 space-y-3">
          <p className="text-sm font-semibold">Nieuwe spiergroep</p>
          <input
            type="text"
            value={newGroupLabel}
            onChange={e => setNewGroupLabel(e.target.value)}
            placeholder="bv. Benen, Armen..."
            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2.5 text-base focus:border-emerald-500 outline-none"
            autoFocus
          />
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => { setShowAddGroup(false); setNewGroupLabel(''); }} className="py-2.5 rounded-lg bg-zinc-800 text-zinc-300 text-sm font-medium">
              Annuleer
            </button>
            <button onClick={addGroup} className="py-2.5 rounded-lg bg-emerald-500 text-zinc-950 text-sm font-bold">
              Toevoegen
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function ExerciseAddRow({ onAdd }) {
  const [name, setName] = useState('');
  const submit = () => {
    if (!name.trim()) return;
    onAdd(name);
    setName('');
  };
  return (
    <div className="flex gap-2">
      <input
        type="text"
        value={name}
        onChange={e => setName(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && submit()}
        placeholder="Nieuwe oefening..."
        className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2.5 text-base focus:border-emerald-500 outline-none"
      />
      <button onClick={submit} className="px-3 rounded-lg bg-zinc-800 hover:bg-emerald-500 hover:text-zinc-950 text-zinc-300 transition">
        <Plus className="w-4 h-4" />
      </button>
    </div>
  );
}

// ============ HELPERS ============

function calculateStreak(sessions, schedule) {
  // Count consecutive weeks (going back from this week) where all non-rest days have a session
  const requiredCount = DAYS.filter(d => schedule[d].type !== 'rest').length;
  if (requiredCount === 0) return 0;

  let streak = 0;
  const now = new Date();
  for (let weekOffset = 0; weekOffset < 52; weekOffset++) {
    const monday = getMondayOfWeek(addDays(now, -weekOffset * 7));
    const mondayStr = toISODate(monday);
    const sundayStr = toISODate(addDays(monday, 6));
    const weekSessions = sessions.filter(s => s.date >= mondayStr && s.date <= sundayStr);

    // Check each non-rest day in schedule
    const plannedDays = DAYS.filter(d => schedule[d].type !== 'rest');
    const allDone = plannedDays.every(day =>
      weekSessions.some(s => s.plannedDay === day)
    );

    // Special case: current week, only require done up to today
    const today = toISODate(new Date());
    const isCurrent = mondayStr <= today && today <= sundayStr;
    if (isCurrent) {
      const todayKey = getDayKey(new Date());
      const todayIdx = DAYS.indexOf(todayKey);
      const daysSoFar = plannedDays.filter(d => DAYS.indexOf(d) <= todayIdx);
      // If this week has no required days passed yet, count it as ongoing (don't break streak)
      const partialDone = daysSoFar.every(day => weekSessions.some(s => s.plannedDay === day));
      if (partialDone) { streak++; continue; }
      // Otherwise break
      break;
    }
    if (allDone) streak++; else break;
  }
  return streak;
}
