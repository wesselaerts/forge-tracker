# FORGE — Sport Tracker PWA

Persoonlijke sport- en krachttracker. Werkt als app op je iPhone (PWA), maar je host hem zelf gratis op GitHub Pages.

## Snel deployen op GitHub Pages

### Stap 1 — Nieuwe repository aanmaken
1. Ga naar https://github.com/new
2. Geef een naam, bijvoorbeeld `forge-tracker`
3. Zet hem op **Public** (gratis GitHub Pages werkt alleen op public repos, tenzij je Pro hebt)
4. Klik op **Create repository**

### Stap 2 — Bestanden uploaden
Je hoeft alleen de inhoud van de map `public/` te uploaden. Dat zijn:

```
index.html
app.js
manifest.json
service-worker.js
icon-192.png
icon-512.png
icon-512-maskable.png
icon-180.png
favicon.png
```

**Upload via de browser** (snelste manier, geen git nodig):
1. Open je nieuwe lege repo op GitHub
2. Klik op "uploading an existing file" (of de knop **Add file** > **Upload files**)
3. Sleep alle bestanden uit `public/` in het venster
4. Onderaan: klik **Commit changes**

**Of via de command line** (als je dat fijner vindt):
```bash
cd public
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/JOUWUSERNAME/forge-tracker.git
git push -u origin main
```

### Stap 3 — GitHub Pages aanzetten
1. Ga naar je repository → **Settings** (tabblad bovenin)
2. In het linkermenu: klik **Pages**
3. Onder **Source**: kies **Deploy from a branch**
4. Onder **Branch**: kies `main` en map `/ (root)`, klik **Save**
5. Wacht ~1 minuut. Bovenaan verschijnt een groen vakje met je URL, bijvoorbeeld:
   `https://JOUWUSERNAME.github.io/forge-tracker/`

### Stap 4 — Op je iPhone installeren
1. Open de URL in **Safari** op je iPhone (moet Safari zijn, niet Chrome — alleen Safari ondersteunt PWAs op iOS)
2. Druk op de **Deel-knop** onderin (vierkantje met pijl omhoog)
3. Scroll en tap **"Zet op beginscherm"** (Engels: *Add to Home Screen*)
4. Geef hem een naam (bijvoorbeeld "Forge"), tap **Toevoegen**
5. Je hebt nu het Forge-icoon op je beginscherm. Open hem en hij draait fullscreen, zonder Safari-balk

### Stap 5 — Op je Mac
Gewoon dezelfde URL openen in Safari/Chrome op je Mac. Werkt direct.

---

## Belangrijk om te weten

### Data is per device
Elke device (iPhone, Mac) heeft zijn **eigen `localStorage`**. Data wordt niet automatisch gesynchroniseerd. Concreet:
- Sessies die je op je iPhone logt, zie je niet op je Mac (en andersom)
- Als je in de gym je iPhone gebruikt en thuis je Mac, kies één device als "main"

Wil je later sync? Dan is er een gratis Supabase- of Firebase-laag bovenop te zetten — dat kunnen we als upgrade doen.

### Je data backup-en
Op de Stats-tab kun je via **"Exporteer alles als CSV"** een backup maken van al je data. Doe dit af en toe, vooral voordat je iets riskants doet (Safari cache wissen, browser opnieuw installeren, etc).

### Updates uitrollen
Als je later iets wilt wijzigen aan de app:
1. Wijzig de source (`src/SportTracker.jsx`)
2. Run `npm run build` (dit maakt een nieuwe `app.js`)
3. Bump het `CACHE_VERSION` in `service-worker.js` (bv. `'forge-v2'`) — anders blijft de oude versie gecached
4. Upload de nieuwe `app.js` en `service-worker.js` naar GitHub
5. Op je iPhone: open de PWA, hij update zichzelf in de achtergrond. Sluit hem en open opnieuw → nieuwe versie

### Project bouwen vanaf scratch
Als je vanaf de source-code wilt herbouwen:
```bash
npm install
npm run build
# output staat in public/app.js
```

---

## Bestandsstructuur

```
forge-pwa/
├── package.json           # npm dependencies + build script
├── src/
│   ├── main.jsx           # React entry point
│   └── SportTracker.jsx   # de hele app
├── public/                # ← dit hele mapje deploy je
│   ├── index.html
│   ├── app.js             # gebundelde React app (esbuild output)
│   ├── manifest.json
│   ├── service-worker.js
│   └── icon-*.png
└── README.md
```

---

## Gebouwd met
- React 18
- Recharts voor grafieken
- Lucide voor iconen
- Tailwind CSS (via Play CDN)
- Esbuild voor bundeling
