/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,jsx,ts,tsx}',
    './public/index.html'
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['Bricolage Grotesque', 'system-ui', 'sans-serif'],
        sans: ['Manrope', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace']
      }
    }
  },
  // Safelist patterns we use dynamically
  safelist: [
    'text-emerald-400', 'text-red-400', 'text-zinc-500', 'text-zinc-600',
    'bg-emerald-500', 'bg-emerald-400', 'bg-zinc-900', 'bg-zinc-800', 'bg-zinc-950'
  ],
  plugins: []
};
